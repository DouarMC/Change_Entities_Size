import { EntityScaleComponent, system } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";
export function createChangeEntitySizeFormUI() {
    return new ModalFormData().title("Change Entity Size");
}
;
export function changeSizeByFormUI(playerConfig, entityInteracted) {
    system.run(async () => {
        const scaleComp = entityInteracted.getComponent(EntityScaleComponent.componentId);
        const changeEntitySizeFormData = createChangeEntitySizeFormUI().textField(`Change ${entityInteracted.typeId} size`, "Entity Size", scaleComp.value.toFixed(1));
        const result = await changeEntitySizeFormData.show(playerConfig);
        if (result.canceled)
            return;
        const valueChoosen = Number(result.formValues[0]);
        if (isNaN(valueChoosen))
            return playerConfig.sendMessage("§cValue has to be a number !");
        if (!(valueChoosen >= 0.1 && valueChoosen <= 10))
            return playerConfig.sendMessage("§cValue has to be between 0.1 and 10 !");
        scaleComp.value = valueChoosen;
    });
}
;
