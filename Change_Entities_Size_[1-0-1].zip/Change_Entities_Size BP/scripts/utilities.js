import { EntityScaleComponent, system } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";
export class ModalFormDataCollection {
    static createChangeEntitySizeFormUI() {
        return new ModalFormData().title("Change Entity Size");
    }
    ;
}
;
export class Utilities {
    static changeSizeByFormUI(playerConfig, entityInteracted) {
        const scaleComp = entityInteracted.getComponent(EntityScaleComponent.componentId);
        system.run(async () => {
            const changeEntitySizeFormData = ModalFormDataCollection.createChangeEntitySizeFormUI()
                .slider(`Change ${entityInteracted.typeId} size`, 0.1, 10.0, 0.1, scaleComp.value);
            const result = await changeEntitySizeFormData.show(playerConfig);
            if (result.canceled)
                return;
            scaleComp.value = result.formValues[0];
        });
    }
    ;
}
;
