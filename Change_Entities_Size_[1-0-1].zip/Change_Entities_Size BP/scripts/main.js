import { world, EntityScaleComponent } from '@minecraft/server';
import { Utilities } from 'utilities';
//Loop
world.beforeEvents.playerInteractWithEntity.subscribe((eventData) => {
    const { itemStack = undefined, player, target } = eventData;
    if (itemStack === undefined)
        return;
    if (itemStack.typeId !== "douarmc_change_entities_size:size_changer")
        return;
    eventData.cancel = true;
    if (!target.hasComponent(EntityScaleComponent.componentId))
        return;
    Utilities.changeSizeByFormUI(player, target);
});
