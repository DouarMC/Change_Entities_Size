import { world, EntityScaleComponent } from '@minecraft/server';
import * as FUNCTIONS_UTILS from "utilities/functions";
/**
 * Ouvre et gère un server form UI quand le joueur utilise le Size Changer sur une entité
 */
world.beforeEvents.playerInteractWithEntity.subscribe((eventData) => {
    const { itemStack = undefined, player, target } = eventData;
    /* CONDITION D'ARRÊT */ if (target.matches({ families: ["mob"] }) === false)
        return;
    /* CONDITION D'ARRÊT */ if (target.hasComponent(EntityScaleComponent.componentId) === false)
        return;
    /* CONDITION D'ARRÊT */ if (itemStack === undefined || itemStack.typeId !== "douarmc:size_changer")
        return;
    //-------------
    eventData.cancel = true;
    FUNCTIONS_UTILS.changeSizeByFormUI(player, target);
});
