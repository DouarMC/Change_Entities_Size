import * as ALL_EXPORTS from "exports";
ALL_EXPORTS;
