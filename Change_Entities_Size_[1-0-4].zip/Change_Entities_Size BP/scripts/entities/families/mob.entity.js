import { world, EntityScaleComponent } from '@minecraft/server';
import * as FUNCTIONS_UTILS from "utilities/functions";
world.beforeEvents.playerInteractWithEntity.subscribe((eventData) => {
    const { itemStack = undefined, player, target } = eventData;
    if (target.matches({ families: ["mob"] }) === false)
        return;
    if (target.hasComponent(EntityScaleComponent.componentId) === false)
        return;
    if (itemStack === undefined || itemStack.typeId !== "douarmc:size_changer")
        return;
    //-------------
    eventData.cancel = true;
    FUNCTIONS_UTILS.changeSizeByFormUI(player, target);
});
