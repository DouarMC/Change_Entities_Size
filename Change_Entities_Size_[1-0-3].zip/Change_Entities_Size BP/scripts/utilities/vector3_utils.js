export class Vector3Utils {
    static add(vector1, vector2) {
        return { x: vector1.x + vector2.x, y: vector1.y + vector2.y, z: vector1.z + vector2.z };
    }
    ;
    static substract(vector1, vector2) {
        return { x: vector1.x - vector2.x, y: vector1.y - vector2.y, z: vector1.z - vector2.z };
    }
    ;
    static scale(vector1, scale) {
        return { x: vector1.x * scale, y: vector1.y * scale, z: vector1.z * scale };
    }
    ;
}
;
